#define VOICE_SATELLITE_WIFI_SSID       "IOT"
#define VOICE_SATELLITE_WIFI_PASSWORD   "42ef36efac"

#define VOICE_SATELLITE_CORE_HOST       "172.16.2.30"
#define VOICE_SATELLITE_CORE_PORT       8081
#define VOICE_SATELLITE_CORE_PATH       "/api/v1/voice/live"
#define VOICE_SATELLITE_CORE_TLS        0

#define VOICE_SATELLITE_CORE_TOKEN      "jv_9e15880fd4db_gEnIxLDTGP97tKU0i-R5UOEM_djFtFsVVbxIlX4MhvE"

#define VOICE_SATELLITE_SATELLITE_ID    "satellite-waveshare-01"
#define VOICE_SATELLITE_SATELLITE_NAME  "Waveshare Test"

#define VOICE_SATELLITE_WAVESHARE_SPEAKER_VOLUME 30
#define VOICE_SATELLITE_WAVESHARE_MIC_GAIN       70

// Gewuenschte TTS-Qualitaet fuer diesen ESP32:
//   "low"    -> Core quality=low (Default, schnell fuer Satelliten)
//   "medium" -> Core quality=balanced
//   "high"   -> Core quality=high
#define VOICE_SATELLITE_TTS_QUALITY      "low"

// Maximale Aufnahmezeit
#define VOICE_SATELLITE_RECORD_MS                 10000

// Automatisch nach Stille absenden
#define VOICE_SATELLITE_SILENCE_DETECTION         1
#define VOICE_SATELLITE_SILENCE_THRESHOLD         500
#define VOICE_SATELLITE_SILENCE_TIMEOUT_MS        900
#define VOICE_SATELLITE_SILENCE_MIN_SPEECH_MS     250
#define VOICE_SATELLITE_SILENCE_ARM_MS            300

// Lokales Wakeword
#define VOICE_SATELLITE_WAKEWORD_ENABLED          1
#define VOICE_SATELLITE_WAKEWORD_NAME             "Hi ESP"

// Display Rotation
#define VOICE_SATELLITE_DISPLAY_ROTATION 180